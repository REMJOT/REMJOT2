# REMJOT2 — Complete Setup Guide

Step-by-step instructions for creating the REMJOT2 project in Xcode 26 and
wiring in the RecallCore package (the shared data layer).

The package IDs in PersistenceController.swift are already set to:
  App Group:         group.com.nelson.remjot2
  iCloud container:  iCloud.com.nelson.remjot2

---

## Part 1 — Create the project (5 min)

1. Open Xcode. In the Welcome window click "Create New Project..."
   (or File > New > Project..., shortcut Shift-Cmd-N).

2. In the template sheet, click the **iOS** tab at the top,
   select the plain **App** template (first icon), click **Next**.

3. Fill in the options sheet EXACTLY like this:

   | Field                   | Value                          |
   |-------------------------|--------------------------------|
   | Product Name            | REMJOT2                        |
   | Team                    | Nelson (Personal Team)         |
   | Organization Identifier | com.nelson                     |
   | Bundle Identifier       | (auto: com.nelson.REMJOT2)     |
   | Interface               | SwiftUI                        |
   | Language                | Swift                          |
   | Testing System          | None                           |
   | Storage                 | **None**  <-- IMPORTANT        |

   WHY "Storage: None" when we ARE using Core Data: if you pick
   "Core Data" here, Xcode generates its own Persistence.swift and a
   second data model inside the app, which collides with the one that
   ships inside RecallCore. The package owns the entire data stack.

   If the Team menu is empty: Xcode > Settings > Accounts > "+" >
   sign in with your Apple ID, then come back and select it.

4. Click **Next**, choose a save location (e.g. ~/Developer),
   leave "Create Git repository" checked, click **Create**.

5. SMOKE TEST: plug in your iPhone 13 (or pick a simulator from the
   device menu in the toolbar) and press Cmd-R. Confirm you see
   "Hello, world!" before continuing — this proves signing works.

---

## Part 2 — Add the RecallCore package (3 min)

6. Unzip RecallCore.zip and move the RecallCore folder somewhere
   permanent — e.g. NEXT TO your REMJOT2 project folder, not inside it:

   ~/Developer/
   ├── REMJOT2/        <- the Xcode project
   └── RecallCore/     <- this package

7. In Xcode: File > Add Package Dependencies...
   Click the **"Add Local..."** button (bottom-left of the sheet),
   select the RecallCore folder, click **Add Package**.

8. On the product sheet that follows, make sure the RecallCore library
   is checked for the **REMJOT2** target, then click **Add Package**.

---

## Part 3 — Capabilities (5 min)

9. Click the blue REMJOT2 project icon at the top of the left sidebar,
   select the **REMJOT2** target, open **Signing & Capabilities**.

10. Confirm "Automatically manage signing" is checked and your Team
    is selected.

11. Click **+ Capability** (top-left of the pane) and add these three,
    one at a time:

    a. **iCloud** — check the "CloudKit" box, then click "+" under
       Containers and create:  iCloud.com.nelson.remjot2

    b. **App Groups** — click "+" and create:  group.com.nelson.remjot2

    c. **Background Modes** — check "Background fetch" and
       "Background processing" (needed later for the Echo scheduler).

    The IDs must match the constants in PersistenceController.swift —
    they are already set to these exact values, so no code edits needed
    if you use the names above.

---

## Part 4 — Wire it up and test (5 min)

12. Open REMJOT2App.swift (Xcode created it) and replace its contents:

    import SwiftUI
    import RecallCore

    @main
    struct REMJOT2App: App {
        let persistence = PersistenceController.shared

        var body: some Scene {
            WindowGroup {
                ContentView()
                    .environment(\.managedObjectContext, persistence.viewContext)
            }
        }
    }

13. SMOKE TEST 2 — drop this button anywhere in ContentView and run
    on your iPhone:

    Button("Test save") {
        let draft = MemoryDraft(content: "First memory!", mode: .text)
        let enriched = EnrichedDraft(draft: draft, people: [],
                                     embedding: [], predictedTopic: "Test")
        let ctx = PersistenceController.shared.newBackgroundContext()
        ctx.perform { try? enriched.persist(in: ctx) }
    }

    Tap it. If nothing crashes, the Core Data + CloudKit stack is alive.

---

## CloudKit notes

- First run should be on a REAL device signed into iCloud — simulator
  CloudKit sync is unreliable. Your iPhone 13 is perfect.
- The CloudKit schema builds itself lazily in the Development
  environment the first time you save. Before any App Store release,
  deploy the schema to Production in the CloudKit Console (one click).
- No RLS policies to fight here, unlike Supabase — CloudKit's private
  database is per-user by design.
- Keep the model CloudKit-legal when adding fields: attributes optional
  or defaulted, relationships with inverses, no unique constraints.

---

## Build order

1. DONE — Core Data model + CloudKit container (this guide)
2. CaptureSheet with text mode — save/read working end to end
3. Voice capture (SFSpeechRecognizer, on-device)
4. OCR (DataScannerViewController)
5. JourneyView timeline (@FetchRequest sorted by createdAt)
6. IntelligenceService (NLTagger people -> NLEmbedding vectors)
7. EchoScheduler + WidgetKit widget
8. Share Extension (App Group is already set up for it)
